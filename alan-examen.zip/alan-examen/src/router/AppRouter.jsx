import React, { useContext, useEffect } from 'react'
import SignInPage from '../modules/auth/SignInPage';
import AuthContext from '../config/context/auth-context';
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import Error from '../modules/temp/Error';
import AdminLayouts from '../modules/admin/AdminLayouts';


function AppRouter() {
  const { user } = useContext(AuthContext);

  const router = createBrowserRouter(
    createRoutesFromElements(
      <>
        {user.signed ? (
          <Route
            path="/"
            element={
              <AdminLayouts>
                <Route
                  path="/"
                  element={
                    <>
                      {user.role === "ADMIN_ROLE" && <Navigate to="/admin" replace />}
                      {user.role === "USER_ROLE" && <Navigate to="/user" replace />}
                      {user.role === "CLIENT_ROLE" && <Navigate to="/client" replace />}
                    </>
                  }
                />
                <Route path="/admin" element={user.role === "ADMIN_ROLE" ? <>ROLE: ADMIN</> : <Error />} />
                <Route path="/user" element={user.role === "USER_ROLE" ? <>ROLE: USER</> : <Error />} />
                <Route path="/client" element={user.role === "CLIENT_ROLE" ? <>ROLE: CLIENT</> : <Error />} />
              </AdminLayouts>
            }
          />
        ) : (
          <Route path="/" element={<SignInPage />} />
        )}
        <Route path="/*" element={<Error />} />
      </>
    )
  );

  return <RouterProvider router={router} />;
}

export default AppRouter;